
import React, { useState, useEffect } from 'react';
import { User, Loan, Block, InvestmentAsset } from './types';
import { blockchain } from './services/blockchainService';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [chain, setChain] = useState<Block[]>([]);

  useEffect(() => {
    setChain(blockchain.getChain());
  }, []);

  const syncChainAndTransitionStatus = (blockIndex: number) => {
    setChain(blockchain.getChain());
    // After 5 seconds, transition the block to validated status
    setTimeout(() => {
      blockchain.setBlockStatus(blockIndex, 'validated');
      setChain(blockchain.getChain());
    }, 5000);
  };

  const handleLogin = (userData: User) => {
    setUser(userData);
    blockchain.addBlock(`User logged in: ${userData.name}`).then(b => {
      syncChainAndTransitionStatus(b.index);
    });
  };

  const handleLogout = () => {
    setUser(null);
  };

  const handleUpdateWallet = (amount: number, reason: string) => {
    if (!user) return;
    const newBalance = user.walletBalance + amount;
    setUser({ ...user, walletBalance: newBalance });
    blockchain.addBlock(`Action: ${reason} | Change: ₹${amount} | New Balance: ₹${newBalance}`).then(b => {
      syncChainAndTransitionStatus(b.index);
    });
  };

  const handleAddLoan = (amount: number) => {
    const newLoan: Loan = {
      id: Math.random().toString(36).substr(2, 9),
      amount,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'active',
      interest: 5
    };
    setLoans([...loans, newLoan]);
    handleUpdateWallet(amount, `Loan Disbursed (ID: ${newLoan.id})`);
  };

  const handleInvestment = (asset: InvestmentAsset, amount: number) => {
    handleUpdateWallet(-amount, `Investment in ${asset.name}`);
  };

  const handleStartupPitch = (title: string, industry: string, desc: string) => {
    blockchain.addBlock(`New Startup Pitch: ${title} (${industry}) - SECURED. Founder: ${user?.name}`).then(b => {
      syncChainAndTransitionStatus(b.index);
    });
  };

  const handleAuditorBooking = (auditor: string) => {
    blockchain.addBlock(`Slot Booked: Consulting with ${auditor}. Session ID: ${Math.floor(Math.random() * 100000)}`).then(b => {
      syncChainAndTransitionStatus(b.index);
    });
    alert(`Success: Your slot with ${auditor} has been secured and logged on the blockchain.`);
  };

  const handleMine = async (onProgress: (n: number) => void) => {
    const newBlock = await blockchain.mineBlock(onProgress);
    syncChainAndTransitionStatus(newBlock.index);
    // Reward is now handled session-wise in BlockchainView at 1 Indian Rupee per 2 seconds
    return newBlock;
  };

  if (!user) {
    return <Auth onAuth={handleLogin} />;
  }

  return (
    <Dashboard 
      user={user} 
      loans={loans} 
      chain={chain}
      onUpdateWallet={handleUpdateWallet}
      onAddLoan={handleAddLoan}
      onMine={handleMine}
      onInvestment={handleInvestment}
      onPitch={handleStartupPitch}
      onBookAuditor={handleAuditorBooking}
      onLogout={handleLogout}
    />
  );
};

export default App;
