
import React, { useState } from 'react';
import { User } from '../types';

interface AuthProps {
  onAuth: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onAuth }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState('');
  const [aadhar, setAadhar] = useState('');
  const [pan, setPan] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !aadhar || !pan) return alert("Please fill all fields");
    
    // In a real app, this would be validated via server
    const newUser: User = {
      name,
      aadhar,
      pan,
      walletBalance: 5000 // Initial 5000 Indian Rupees for first-time users as requested
    };
    onAuth(newUser);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-6">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl">
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <i className="fas fa-coins text-white text-xl"></i>
            </div>
            <h1 className="text-3xl font-bold text-white tracking-tight">Dhana Path</h1>
          </div>
        </div>

        <h2 className="text-xl text-blue-400 font-medium mb-6 text-center">
          {isLogin ? "Welcome Back" : "Create Account"}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-1">Full Name</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              placeholder="Enter your name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-1">Aadhar Number</label>
            <input 
              type="text" 
              value={aadhar}
              onChange={(e) => setAadhar(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              placeholder="12-digit Aadhar"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-1">PAN Number</label>
            <input 
              type="text" 
              value={pan}
              onChange={(e) => setPan(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              placeholder="10-digit PAN"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-3 rounded-xl transition-colors shadow-lg shadow-blue-900/20 mt-4"
          >
            {isLogin ? "Sign In" : "Register"}
          </button>
        </form>

        <p className="mt-6 text-center text-slate-500 text-sm">
          {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
          <button onClick={() => setIsLogin(!isLogin)} className="text-blue-400 hover:text-blue-300 font-medium">
            {isLogin ? "Create one" : "Sign in here"}
          </button>
        </p>

        <div className="mt-8 flex items-center justify-center space-x-2 text-[10px] text-slate-600 uppercase tracking-widest">
          <i className="fas fa-lock"></i>
          <span>End-to-End Encrypted Session</span>
        </div>
      </div>
    </div>
  );
};

export default Auth;
