
import React, { useState } from 'react';
import { User, Loan, Block, InvestmentAsset } from '../types';
import Growth from './views/Growth';
import Library from './views/Library';
import Auditing from './views/Auditing';
import VC from './views/VC';
import Wallet from './views/Wallet';
import BlockchainView from './views/BlockchainView';

interface DashboardProps {
  user: User;
  loans: Loan[];
  chain: Block[];
  onUpdateWallet: (amount: number, reason: string) => void;
  onAddLoan: (amount: number) => void;
  onMine: (onProgress: (n: number) => void) => Promise<Block>;
  onInvestment: (asset: InvestmentAsset, amount: number) => void;
  onPitch: (title: string, industry: string, desc: string) => void;
  onBookAuditor: (name: string) => void;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = (props) => {
  const { user, loans, chain, onUpdateWallet, onAddLoan, onMine, onInvestment, onPitch, onBookAuditor, onLogout } = props;
  const [activeTab, setActiveTab] = useState<'growth' | 'library' | 'auditing' | 'vc' | 'wallet' | 'blockchain'>('growth');

  const tabs = [
    { id: 'growth', label: 'Growth', icon: 'fa-chart-line' },
    { id: 'library', label: 'Library', icon: 'fa-book-open' },
    { id: 'auditing', label: 'Audit & Law', icon: 'fa-file-invoice' },
    { id: 'vc', label: 'Venture Capital', icon: 'fa-handshake' },
    { id: 'wallet', label: 'Wallet', icon: 'fa-wallet' },
    { id: 'blockchain', label: 'Blockchain', icon: 'fa-link' },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'growth': 
        return <Growth loans={loans} onApplyLoan={onAddLoan} walletBalance={user.walletBalance} onInvest={onInvestment} />;
      case 'library': 
        return <Library />;
      case 'auditing': 
        return <Auditing onBook={onBookAuditor} />;
      case 'vc': 
        return <VC onInvest={(amt, name) => onUpdateWallet(-amt, `Invested in ${name}`)} onPitch={onPitch} />;
      case 'wallet': 
        return <Wallet user={user} onRecharge={(amt) => onUpdateWallet(amt, "Recharge via UPI")} />;
      case 'blockchain': 
        return <BlockchainView chain={chain} onMine={onMine} onLogout={onLogout} onUpdateWallet={onUpdateWallet} />;
      default: return null;
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden">
      <aside className="w-20 md:w-64 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0">
        <div className="p-6 mb-8 flex items-center justify-center md:justify-start space-x-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shrink-0 shadow-lg shadow-blue-900/20">
            <i className="fas fa-coins text-white"></i>
          </div>
          <span className="hidden md:block text-xl font-bold text-white tracking-tight">Dhana Path</span>
        </div>

        <nav className="flex-1 space-y-2 px-3">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center justify-center md:justify-start space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === tab.id 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/30' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              <i className={`fas ${tab.icon} text-lg shrink-0`}></i>
              <span className="hidden md:block font-medium">{tab.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className="flex items-center space-x-3 p-2 rounded-xl bg-slate-950/50">
            <div className="w-10 h-10 rounded-full bg-blue-900 flex items-center justify-center text-blue-300 font-bold shrink-0 border border-blue-700">
              {user.name.charAt(0)}
            </div>
            <div className="hidden md:block truncate">
              <p className="text-sm font-semibold text-white truncate">{user.name}</p>
              <p className="text-[10px] text-slate-500 truncate">{user.pan}</p>
            </div>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-20 bg-slate-900/50 backdrop-blur-md border-b border-slate-800 flex items-center justify-between px-8 shrink-0">
          <h2 className="text-xl font-semibold text-white capitalize">{activeTab.replace('-', ' ')}</h2>
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2 text-blue-400 bg-blue-900/20 px-4 py-2 rounded-full border border-blue-900/30">
              <i className="fas fa-indian-rupee-sign text-xs"></i>
              <span className="font-bold tracking-tight">{user.walletBalance.toLocaleString()} Indian Rupees</span>
            </div>
            <div className="hidden sm:flex items-center space-x-1 text-emerald-500 text-[10px] font-bold uppercase tracking-widest bg-emerald-900/20 px-3 py-1 rounded-full border border-emerald-900/30">
              <div className="w-1 h-1 bg-emerald-500 rounded-full animate-pulse"></div>
              <span>Secured Session</span>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 md:p-8">
          <div className="max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
            {renderContent()}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
