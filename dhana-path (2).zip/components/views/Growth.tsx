
import React, { useState, useEffect } from 'react';
import { getMarketUpdates } from '../../services/geminiService';
import { Loan, InvestmentAsset } from '../../types';

interface GrowthProps {
  loans: Loan[];
  onApplyLoan: (amt: number) => void;
  walletBalance: number;
  onInvest: (asset: InvestmentAsset, amount: number) => void;
}

const Growth: React.FC<GrowthProps> = ({ loans, onApplyLoan, walletBalance, onInvest }) => {
  const [updates, setUpdates] = useState<string>("Fetching market insights...");
  const [loanAmount, setLoanAmount] = useState<string>('');
  const [invAmount, setInvAmount] = useState<{[key: string]: string}>({});

  const assets: InvestmentAsset[] = [
    { id: 'gold', name: 'Gold (24K)', type: 'gold', price: 6250, change: 0.5 },
    { id: 'silver', name: 'Silver', type: 'silver', price: 74, change: -1.2 },
    { id: 'nifty', name: 'Nifty 50', type: 'index', price: 22040, change: 0.8 },
    { id: 'mf_blue', name: 'HDFC Bluechip MF', type: 'mutual_fund', price: 112, change: 1.5 },
  ];

  useEffect(() => {
    getMarketUpdates().then(setUpdates);
  }, []);

  const handleApply = () => {
    const amt = parseFloat(loanAmount);
    if (!amt || amt <= 0) return alert("Enter valid amount");
    onApplyLoan(amt);
    setLoanAmount('');
    alert("Loan approved instantly with 5% interest!");
  };

  const handleAssetInvest = (asset: InvestmentAsset) => {
    const amt = parseFloat(invAmount[asset.id] || '0');
    if (amt <= 0) return alert("Enter valid investment amount");
    if (amt > walletBalance) return alert("Insufficient balance");
    onInvest(asset, amt);
    setInvAmount({ ...invAmount, [asset.id]: '' });
    alert(`Successfully invested ${amt} Indian Rupees in ${asset.name}`);
  };

  return (
    <div className="space-y-8">
      {/* Investment Assets Section */}
      <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-600/20 text-blue-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-coins text-xl"></i>
            </div>
            <h3 className="text-xl font-bold text-white">Market Assets</h3>
          </div>
          <p className="text-slate-500 text-sm italic">Real-time market rates</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {assets.map(asset => (
            <div key={asset.id} className="bg-slate-950 border border-slate-800 rounded-xl p-4 hover:border-blue-500 transition-colors">
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs text-slate-500 uppercase font-bold">{asset.type.replace('_', ' ')}</span>
                <span className={`text-[10px] font-bold ${asset.change >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                  {asset.change >= 0 ? '+' : ''}{asset.change}%
                </span>
              </div>
              <h4 className="text-white font-semibold mb-1">{asset.name}</h4>
              <p className="text-blue-400 text-lg font-bold mb-4">₹{asset.price.toLocaleString()}</p>
              <div className="space-y-2">
                <input 
                  type="number"
                  placeholder="Amt in ₹"
                  value={invAmount[asset.id] || ''}
                  onChange={(e) => setInvAmount({...invAmount, [asset.id]: e.target.value})}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white outline-none focus:ring-1 focus:ring-blue-500"
                />
                <button 
                  onClick={() => handleAssetInvest(asset)}
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold py-1.5 rounded-lg transition-colors uppercase"
                >
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Insights */}
        <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-10 h-10 bg-indigo-600/20 text-indigo-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-bolt text-xl"></i>
            </div>
            <h3 className="text-xl font-bold text-white">Smart Insights</h3>
          </div>
          <div className="bg-slate-950 rounded-xl p-6 border border-slate-800 min-h-[140px]">
            <p className="text-slate-300 leading-relaxed text-sm italic">"{updates}"</p>
          </div>
        </section>

        {/* Loan Service */}
        <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-10 h-10 bg-indigo-600/20 text-indigo-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-hand-holding-usd text-xl"></i>
            </div>
            <h3 className="text-xl font-bold text-white">Instant Credit</h3>
          </div>
          <div className="flex space-x-2 mb-6">
            <input 
              type="number"
              value={loanAmount}
              onChange={(e) => setLoanAmount(e.target.value)}
              placeholder="Loan amount (₹)"
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
            />
            <button 
              onClick={handleApply}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-6 py-3 rounded-xl text-sm transition-colors"
            >
              Apply
            </button>
          </div>
          <div className="space-y-2 max-h-[100px] overflow-y-auto pr-2">
            {loans.length === 0 ? (
              <p className="text-slate-600 text-xs italic text-center">No active loans.</p>
            ) : (
              loans.map(loan => (
                <div key={loan.id} className="bg-slate-950 border border-slate-800 rounded-lg p-2 flex justify-between items-center">
                  <span className="text-white text-xs">₹{loan.amount.toLocaleString()} Indian Rupees</span>
                  <span className="text-[10px] text-red-500 font-bold uppercase">Due {loan.dueDate}</span>
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Growth;
