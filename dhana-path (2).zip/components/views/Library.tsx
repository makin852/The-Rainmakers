
import React from 'react';

const Library: React.FC = () => {
  const articles = [
    { title: "Basics of Blockchain Mining", link: "https://ethereum.org/en/developers/docs/consensus-mechanisms/pow/mining/", icon: "fa-link" },
    { title: "Understanding Compound Interest", link: "https://www.investopedia.com/terms/c/compoundinterest.asp", icon: "fa-percentage" },
    { title: "Tax Savings Guide for Indians", link: "https://economictimes.indiatimes.com/wealth/tax/saving", icon: "fa-shield-halved" },
    { title: "Venture Capital Fundamentals", link: "https://hbr.org/1998/11/how-venture-capital-works", icon: "fa-building" },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-white mb-2">Financial Library</h3>
        <p className="text-slate-500">Expand your knowledge with curated resources.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {articles.map((article, idx) => (
          <a 
            key={idx}
            href={article.link}
            target="_blank"
            rel="noopener noreferrer"
            className="group bg-slate-900 border border-slate-800 hover:border-blue-500 rounded-2xl p-6 transition-all duration-300 flex items-start space-x-4 shadow-lg"
          >
            <div className="w-12 h-12 bg-slate-800 text-blue-500 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <i className={`fas ${article.icon} text-xl`}></i>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white group-hover:text-blue-400 transition-colors">{article.title}</h4>
              <p className="text-slate-500 text-sm mt-1">External Resource • Read Article</p>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};

export default Library;
