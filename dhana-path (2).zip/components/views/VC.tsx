
import React, { useState } from 'react';

interface VCProps {
  onInvest: (amount: number, startupName: string) => void;
  onPitch: (title: string, industry: string, desc: string) => void;
}

const VC: React.FC<VCProps> = ({ onInvest, onPitch }) => {
  const startups = [
    {
      id: 'st-1',
      name: "Coimbatore Textile Hub",
      location: "Tamil Nadu",
      founder: "Rajesh",
      description: "Organic cotton production and export with state-of-the-art power looms.",
      fundingGoal: 50000
    },
    {
      id: 'st-2',
      name: "Bengaluru Poultry Pro",
      location: "Karnataka",
      founder: "Darshit",
      description: "IoT-based climate controlled poultry farming for high yield organic produce.",
      fundingGoal: 35000
    }
  ];

  const [invAmount, setInvAmount] = useState<{[key: string]: string}>({});
  const [pitch, setPitch] = useState({ title: '', industry: '', desc: '' });

  const handleInvest = (id: string, name: string) => {
    const amt = parseFloat(invAmount[id] || '0');
    if (amt <= 0) return alert("Enter amount");
    onInvest(amt, name);
    setInvAmount({ ...invAmount, [id]: '' });
    alert(`Investment of ₹${amt} for ${name} recorded on blockchain.`);
  };

  const handlePitchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pitch.title || !pitch.desc) return alert("Please fill your pitch details");
    onPitch(pitch.title, pitch.industry, pitch.desc);
    setPitch({ title: '', industry: '', desc: '' });
    alert("Your startup pitch has been registered and secured on the blockchain.");
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
      {/* Featured Startups */}
      <div className="xl:col-span-2 space-y-8">
        <h3 className="text-2xl font-bold text-white">Active Opportunities</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {startups.map((s) => (
            <div key={s.id} className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden hover:border-blue-500 transition-colors group flex flex-col">
              <div className="p-8 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="text-xl font-bold text-white group-hover:text-blue-400 transition-colors">{s.name}</h4>
                    <p className="text-blue-400 text-xs mt-1">{s.location} • {s.founder}</p>
                  </div>
                  <div className="w-10 h-10 bg-blue-600/10 rounded-xl flex items-center justify-center border border-blue-500/20">
                    <i className="fas fa-industry text-blue-500 text-sm"></i>
                  </div>
                </div>
                <p className="text-slate-400 text-sm leading-relaxed mb-8 flex-1">{s.description}</p>
                <div className="space-y-4">
                  <div className="flex space-x-2">
                    <input 
                      type="number" 
                      value={invAmount[s.id] || ''}
                      onChange={(e) => setInvAmount({...invAmount, [s.id]: e.target.value})}
                      placeholder="Amount (₹)"
                      className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white outline-none focus:ring-1 focus:ring-blue-500"
                    />
                    <button 
                      onClick={() => handleInvest(s.id, s.name)}
                      className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-6 py-3 rounded-xl text-sm transition-all"
                    >
                      Invest
                    </button>
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                    <span>Target: ₹{s.fundingGoal.toLocaleString()}</span>
                    <span className="text-emerald-500">Verified Asset</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pitch Form */}
      <div className="xl:col-span-1">
        <section className="bg-slate-900 border border-slate-800 rounded-3xl p-8 sticky top-8 shadow-2xl">
          <h3 className="text-xl font-bold text-white mb-2">Grab Investors</h3>
          <p className="text-slate-500 text-xs mb-6 leading-relaxed">Pitch your startup idea and secure your intellectual property on the Dhana Path ledger.</p>
          
          <form onSubmit={handlePitchSubmit} className="space-y-5">
            <div>
              <label className="block text-[10px] text-slate-500 uppercase font-bold mb-2 ml-1">Startup Name</label>
              <input 
                type="text" 
                value={pitch.title}
                onChange={(e) => setPitch({...pitch, title: e.target.value})}
                placeholder="Enter company name"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-4 text-sm text-white focus:ring-1 focus:ring-blue-500 outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-[10px] text-slate-500 uppercase font-bold mb-2 ml-1">Industry Sector</label>
              <input 
                type="text" 
                value={pitch.industry}
                onChange={(e) => setPitch({...pitch, industry: e.target.value})}
                placeholder="e.g. AgriTech, FinTech"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-4 text-sm text-white focus:ring-1 focus:ring-blue-500 outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-[10px] text-slate-500 uppercase font-bold mb-2 ml-1">Value Proposition</label>
              <textarea 
                rows={5}
                value={pitch.desc}
                onChange={(e) => setPitch({...pitch, desc: e.target.value})}
                placeholder="What problem are you solving?"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-4 text-sm text-white focus:ring-1 focus:ring-blue-500 outline-none resize-none transition-all"
              />
            </div>
            <button className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-5 rounded-xl shadow-lg shadow-emerald-900/10 transition-all flex items-center justify-center active:scale-95">
              <i className="fas fa-paper-plane mr-2"></i> Submit Blockchain Pitch
            </button>
          </form>
        </section>
      </div>
    </div>
  );
};

export default VC;
