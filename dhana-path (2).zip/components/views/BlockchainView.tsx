
import React, { useState, useEffect, useRef } from 'react';
import { Block } from '../../types';

interface BlockchainViewProps {
  chain: Block[];
  onMine: (progress: (n: number) => void) => Promise<Block>;
  onLogout: () => void;
  onUpdateWallet: (amount: number, reason: string) => void;
}

const BlockchainView: React.FC<BlockchainViewProps> = ({ chain, onMine, onLogout, onUpdateWallet }) => {
  const [isMining, setIsMining] = useState(false);
  const [nonceProgress, setNonceProgress] = useState(0);
  const [showSleepMode, setShowSleepMode] = useState(false);
  const [time, setTime] = useState(new Date());
  const [blockCooldown, setBlockCooldown] = useState(5);
  
  // Session Stats
  const [sessionBlocksMined, setSessionBlocksMined] = useState(0);
  const [hashRate, setHashRate] = useState(0);
  const [sessionStartTime, setSessionStartTime] = useState<Date | null>(null);
  const isMiningSessionActive = useRef(false);

  useEffect(() => {
    if (showSleepMode) {
      const timer = setInterval(() => setTime(new Date()), 1000);
      // Simulate hash rate fluctuations
      const hashTimer = setInterval(() => {
        setHashRate(Math.floor(Math.random() * 500) + 1200); // 1200-1700 H/s
      }, 2000);
      return () => {
        clearInterval(timer);
        clearInterval(hashTimer);
      };
    }
  }, [showSleepMode]);

  const startMiningSession = async () => {
    setShowSleepMode(true);
    setIsMining(true);
    isMiningSessionActive.current = true;
    const start = new Date();
    setSessionStartTime(start);
    setSessionBlocksMined(0);

    // Continuous mining loop: 1 block every 5 seconds
    while (isMiningSessionActive.current) {
      setNonceProgress(0);
      setBlockCooldown(5);
      
      // Start a countdown for the 5-second cycle
      const countdownInterval = setInterval(() => {
        setBlockCooldown((prev) => Math.max(0, prev - 1));
      }, 1000);

      try {
        // Perform the actual hashing
        await onMine((n) => {
          if (!isMiningSessionActive.current) return;
          setNonceProgress(n);
        });

        // Ensure at least 5 seconds have passed before finalizing the block
        await new Promise(r => setTimeout(r, 5000));

        if (isMiningSessionActive.current) {
          setSessionBlocksMined(prev => prev + 1);
        }
      } catch (e) {
        console.error("Mining error:", e);
        clearInterval(countdownInterval);
        break;
      }
      
      clearInterval(countdownInterval);
      if (!isMiningSessionActive.current) break;
    }
    
    setIsMining(false);
  };

  const stopMiningSession = () => {
    if (!isMiningSessionActive.current) return;

    // Calculate time-based reward: 1 Indian Rupee per 2 seconds
    const end = new Date();
    const elapsedSeconds = sessionStartTime 
      ? Math.floor((end.getTime() - sessionStartTime.getTime()) / 1000) 
      : 0;
    const sessionReward = Math.floor(elapsedSeconds / 2);

    isMiningSessionActive.current = false;
    setIsMining(false);
    setShowSleepMode(false);

    if (sessionReward > 0) {
      onUpdateWallet(sessionReward, `Mining Session Reward (${elapsedSeconds}s)`);
      alert(`Mining session ended. You earned ₹${sessionReward} Indian Rupees (Rate: ₹1 / 2s).`);
    } else {
      alert("Mining session ended. No rewards earned (session too short).");
    }
  };

  if (showSleepMode) {
    const elapsedSeconds = sessionStartTime 
      ? Math.floor((time.getTime() - sessionStartTime.getTime()) / 1000) 
      : 0;
    const avgBlockTime = sessionBlocksMined > 0 
      ? (elapsedSeconds / sessionBlocksMined).toFixed(1) 
      : "---";
    const currentSessionReward = Math.floor(elapsedSeconds / 2);

    return (
      <div className="fixed inset-0 z-[100] bg-[#010409] flex flex-col items-center justify-center p-8 transition-opacity duration-1000 animate-in fade-in">
        <div className="text-center space-y-10 max-w-2xl w-full">
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-blue-600/10 blur-[120px] rounded-full animate-pulse"></div>
            <h1 className="text-8xl font-thin text-blue-500/90 tracking-tighter relative z-10 font-mono">
              {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </h1>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full">
            <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4">
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Blocks Mined</p>
              <p className="text-2xl font-black text-white">{sessionBlocksMined}</p>
            </div>
            <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4">
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Hash Rate</p>
              <p className="text-2xl font-black text-blue-400">{hashRate} <span className="text-xs font-normal">H/s</span></p>
            </div>
            <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4">
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Cycle Timer</p>
              <p className="text-2xl font-black text-white">{blockCooldown}s</p>
              <p className="text-[8px] text-slate-600 uppercase mt-1">1 Block / 5s</p>
            </div>
            <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4">
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Total Rewards</p>
              <p className="text-2xl font-black text-emerald-500">₹{currentSessionReward}</p>
              <p className="text-[8px] text-emerald-600 font-bold uppercase mt-1">₹1 / 2s</p>
            </div>
          </div>

          <div className="w-full bg-slate-900/50 border border-slate-800 rounded-3xl p-8 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-slate-800 overflow-hidden">
              <div 
                className="h-full bg-blue-600 transition-all duration-1000 ease-linear" 
                style={{ width: `${((5 - blockCooldown) / 5) * 100}%` }}
              ></div>
            </div>
            
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full animate-ping"></span>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                  {blockCooldown === 0 ? "Validating Block..." : "Solving Cryptographic Puzzle"}
                </span>
              </div>
              <span className="text-[10px] text-blue-400 font-mono">NONCE: {nonceProgress.toLocaleString()}</span>
            </div>
            
            <p className="text-slate-500 text-sm italic leading-relaxed">
              Dhana Path mining cycle limited to 5 seconds per block for network stability...
            </p>
          </div>

          <div className="flex flex-col md:flex-row items-center justify-center gap-6 pt-6">
            <button 
              onClick={stopMiningSession}
              className="w-full md:w-auto bg-slate-800 hover:bg-slate-700 text-white px-12 py-4 rounded-2xl font-bold uppercase tracking-widest text-xs transition-all border border-slate-700 active:scale-95"
            >
              Stop Mining
            </button>
            <button 
              onClick={onLogout}
              className="w-full md:w-auto bg-red-900/20 text-red-500 hover:bg-red-900/40 px-12 py-4 rounded-2xl border border-red-900/30 text-xs font-bold uppercase tracking-widest transition-all active:scale-95"
            >
              Secure Logout
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Mining Section */}
      <section className="bg-slate-900 border border-slate-800 rounded-3xl p-10 shadow-2xl relative overflow-hidden">
        <div className="max-w-4xl relative z-10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-8">
            <div className="flex-1">
              <div className="flex items-center space-x-4">
                <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-900/40">
                  <i className="fas fa-cube text-white text-2xl"></i>
                </div>
                <h3 className="text-3xl font-black text-white tracking-tight">Blockchain Mining</h3>
              </div>
            </div>
            
            <div className="shrink-0">
              <button 
                onClick={startMiningSession}
                className="w-full md:w-48 py-5 rounded-2xl font-black transition-all shadow-xl tracking-wider uppercase text-xs bg-blue-600 hover:bg-blue-500 text-white shadow-blue-900/40 active:scale-95"
              >
                Initialize Mining
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-slate-800">
            <div className="flex items-center space-x-3">
              <i className="fas fa-shield-alt text-blue-500 opacity-50"></i>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">1 Block / 5s Limit</span>
            </div>
            <div className="flex items-center space-x-3">
              <i className="fas fa-microchip text-blue-500 opacity-50"></i>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">SHA-256 Protocol</span>
            </div>
            <div className="flex items-center space-x-3">
              <i className="fas fa-network-wired text-blue-500 opacity-50"></i>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Rate Controlled</span>
            </div>
          </div>
        </div>
        
        <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-blue-600/5 to-transparent pointer-events-none"></div>
        <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-blue-600/10 blur-[120px] rounded-full pointer-events-none"></div>
      </section>

      {/* Chain Explorer */}
      <section>
        <div className="flex items-center justify-between mb-8 px-2">
          <div className="flex items-center space-x-3">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <h3 className="text-xl font-bold text-white">Distributed Ledger Explorer</h3>
          </div>
          <span className="text-[10px] font-bold bg-slate-900 text-slate-500 px-4 py-2 rounded-full border border-slate-800 uppercase tracking-widest">
            {chain.length} Immutable Blocks
          </span>
        </div>

        <div className="space-y-4">
          {[...chain].reverse().map((block) => (
            <div 
              key={block.index} 
              className={`bg-slate-900 border ${block.status === 'pending' ? 'border-amber-900/50' : 'border-slate-800'} rounded-2xl p-6 hover:border-blue-900/50 transition-all group relative overflow-hidden`}
            >
              <div className="flex items-start justify-between mb-6 relative z-10">
                <div className="flex items-center space-x-4">
                  <div className={`w-10 h-10 ${block.status === 'pending' ? 'bg-amber-600/20 text-amber-500' : 'bg-blue-600/20 text-blue-500'} rounded-xl flex items-center justify-center font-black border border-current opacity-80`}>
                    {block.index}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white tracking-wide">{block.data}</h4>
                    <p className="text-[10px] text-slate-500 font-medium uppercase mt-0.5 tracking-wider">{new Date(block.timestamp).toLocaleString()}</p>
                  </div>
                </div>
                {block.status === 'pending' ? (
                  <div className="text-[10px] text-amber-500 font-black flex items-center bg-amber-500/10 px-3 py-1.5 rounded-lg border border-amber-500/20 uppercase tracking-tighter animate-pulse">
                    <i className="fas fa-clock mr-1.5"></i> PENDING (5s)
                  </div>
                ) : (
                  <div className="text-[10px] text-emerald-500 font-black flex items-center bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20 uppercase tracking-tighter">
                    <i className="fas fa-check-circle mr-1.5"></i> SECURED
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
                <div className="bg-slate-950/50 rounded-xl p-4 border border-slate-800/50 group-hover:border-slate-700/50 transition-colors">
                  <p className="text-[9px] text-slate-600 uppercase font-black tracking-widest mb-2">Block Hash</p>
                  <p className="text-[10px] text-blue-400 font-mono break-all leading-relaxed">{block.hash}</p>
                </div>
                <div className="bg-slate-950/50 rounded-xl p-4 border border-slate-800/50 group-hover:border-slate-700/50 transition-colors">
                  <p className="text-[9px] text-slate-600 uppercase font-black tracking-widest mb-2">Previous Hash</p>
                  <p className="text-[10px] text-slate-500 font-mono break-all leading-relaxed">{block.prevHash}</p>
                </div>
              </div>
              
              <div className="mt-5 flex items-center space-x-4 relative z-10">
                <div className="flex items-center space-x-2 text-[10px] text-slate-500 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800/50">
                  <span className="font-black uppercase tracking-widest text-[8px]">Proof Nonce:</span>
                  <span className="text-blue-500 font-mono font-bold">{block.nonce}</span>
                </div>
                <div className="w-full h-px bg-slate-800/50 flex-1"></div>
              </div>

              {block.status === 'pending' && (
                <div className="absolute inset-0 bg-amber-600/5 pointer-events-none animate-pulse"></div>
              )}
            </div>
          ))}
        </div>
      </section>
      
      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(250%); }
        }
      `}</style>
    </div>
  );
};

export default BlockchainView;
