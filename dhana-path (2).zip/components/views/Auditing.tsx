
import React, { useState } from 'react';

interface AuditingProps {
  onBook: (auditorName: string) => void;
}

const Auditing: React.FC<AuditingProps> = ({ onBook }) => {
  const auditors = [
    { name: "Veritas Associates", specialty: "Corporate Taxation & Auditing", phone: "+91 98XXX-XXXXX" },
    { name: "S.K. Sharma & Co.", specialty: "Individual IT Filing", phone: "+91 97XXX-XXXXX" },
    { name: "BluePeak Financials", specialty: "GST & Business Compliance", phone: "+91 95XXX-XXXXX" },
  ];

  const legalResources = [
    { name: "Department of Justice", url: "https://doj.gov.in/", desc: "Official Govt Legal Information" },
    { name: "Bar Council of India", url: "http://www.barcouncilofindia.org/", desc: "Find Verified Advocates" },
    { name: "Nyaya Bandhu", url: "https://www.probono-doj.in/", desc: "Govt Pro Bono Legal Services" },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-10">
      <section className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl">
        <div className="flex items-center space-x-4 mb-8">
          <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
            <i className="fas fa-file-invoice-dollar text-xl text-white"></i>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white">Auditing & IT Services</h3>
            <p className="text-slate-500 text-sm">Expert consultation for your financial compliance</p>
          </div>
        </div>

        <div className="grid gap-4">
          {auditors.map((auditor, idx) => (
            <div key={idx} className="bg-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between hover:border-blue-900/50 transition-colors">
              <div>
                <h4 className="text-lg font-bold text-white">{auditor.name}</h4>
                <p className="text-blue-400 text-xs font-medium">{auditor.specialty}</p>
              </div>
              <div className="mt-4 md:mt-0 flex space-x-2">
                <button 
                  onClick={() => onBook(auditor.name)}
                  className="bg-blue-600 hover:bg-blue-500 text-white px-5 py-2.5 rounded-xl font-bold text-xs transition-colors"
                >
                  Book Slot
                </button>
                <a 
                  href={`tel:${auditor.phone}`}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-5 py-2.5 rounded-xl font-bold text-xs transition-colors"
                >
                  Contact
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center">
          <i className="fas fa-balance-scale mr-3 text-blue-500"></i>
          Official Legal Resources (Govt)
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {legalResources.map((res, i) => (
            <a 
              key={i} 
              href={res.url} 
              target="_blank" 
              rel="noreferrer"
              className="bg-slate-950 border border-slate-800 p-6 rounded-2xl hover:border-emerald-500/50 transition-all group"
            >
              <h4 className="text-white font-bold group-hover:text-emerald-400 transition-colors">{res.name}</h4>
              <p className="text-slate-500 text-xs mt-2">{res.desc}</p>
              <div className="mt-4 text-[10px] text-emerald-500 uppercase tracking-widest font-bold">Open Official Portal →</div>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Auditing;
