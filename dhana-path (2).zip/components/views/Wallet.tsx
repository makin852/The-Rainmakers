
import React, { useState } from 'react';
import { User } from '../../types';

interface WalletProps {
  user: User;
  onRecharge: (amt: number) => void;
}

const Wallet: React.FC<WalletProps> = ({ user, onRecharge }) => {
  const [upiId, setUpiId] = useState('');
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleRecharge = () => {
    const amt = parseFloat(amount);
    if (!upiId || !amt || amt <= 0) return alert("Enter valid UPI ID and Amount");
    
    setIsProcessing(true);
    // Simulated UPI verification and bank transfer delay
    setTimeout(() => {
      setIsProcessing(false);
      onRecharge(amt);
      setAmount('');
      setUpiId('');
      alert(`Transaction verified! ₹${amt} added to your secure wallet.`);
    }, 2000);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-gradient-to-br from-blue-900 via-slate-950 to-indigo-950 border border-slate-800 rounded-[2.5rem] p-10 text-white shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/10 blur-[80px] group-hover:bg-blue-600/20 transition-all duration-1000"></div>
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-12">
            <div>
              <p className="text-blue-400 text-xs font-bold uppercase tracking-widest mb-1">Dhana Path Secured</p>
              <h3 className="text-5xl font-black tracking-tight">₹{user.walletBalance.toLocaleString()} <span className="text-xl font-normal opacity-50">Rupees</span></h3>
            </div>
            <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
              <i className="fas fa-fingerprint text-blue-400"></i>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-8">
            <div>
              <p className="text-slate-500 text-[9px] uppercase font-bold tracking-[0.2em] mb-1">Holder</p>
              <p className="text-sm font-semibold">{user.name}</p>
            </div>
            <div className="text-right">
              <p className="text-slate-500 text-[9px] uppercase font-bold tracking-[0.2em] mb-1">Status</p>
              <span className="text-[10px] text-emerald-500 font-bold bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 uppercase">Encrypted</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8">
        <h4 className="text-xl font-bold text-white mb-6 flex items-center">
          <i className="fas fa-paper-plane mr-3 text-blue-500"></i>
          UPI Recharge Portal
        </h4>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] text-slate-500 uppercase font-bold mb-2 ml-1">UPI ID (VPA)</label>
              <input 
                type="text" 
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="username@bank"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-4 text-white focus:ring-1 focus:ring-blue-500 outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-[10px] text-slate-500 uppercase font-bold mb-2 ml-1">Amount (₹)</label>
              <input 
                type="number" 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="e.g. 1000"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-4 text-white focus:ring-1 focus:ring-blue-500 outline-none transition-all"
              />
            </div>
          </div>
          <button 
            onClick={handleRecharge}
            disabled={isProcessing}
            className={`w-full font-bold py-5 rounded-xl transition-all flex items-center justify-center ${
              isProcessing 
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
              : 'bg-blue-600 hover:bg-blue-500 text-white shadow-xl shadow-blue-900/20 active:scale-95'
            }`}
          >
            {isProcessing ? (
              <span className="flex items-center">
                <i className="fas fa-spinner fa-spin mr-2"></i> Verifying with UPI...
              </span>
            ) : (
              "Complete Transaction"
            )}
          </button>
          <div className="flex justify-center space-x-4 pt-4 grayscale opacity-30">
            <i className="fab fa-google-pay text-2xl"></i>
            <i className="fas fa-university text-2xl"></i>
            <i className="fas fa-credit-card text-2xl"></i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Wallet;
