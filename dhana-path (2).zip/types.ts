
export interface User {
  name: string;
  aadhar: string;
  pan: string;
  walletBalance: number;
}

export interface Block {
  index: number;
  timestamp: string;
  data: string;
  prevHash: string;
  hash: string;
  nonce: number;
  status?: 'pending' | 'validated';
}

export interface Loan {
  id: string;
  amount: number;
  dueDate: string;
  status: 'active' | 'paid';
  interest: number;
}

export interface InvestmentAsset {
  id: string;
  name: string;
  type: 'gold' | 'silver' | 'mutual_fund' | 'index';
  price: number;
  change: number;
}

export interface UserInvestment {
  assetId: string;
  assetName: string;
  amount: number;
  units: number;
}

export interface StartupIdea {
  id: string;
  title: string;
  description: string;
  industry: string;
  founder: string;
}

export interface Startup {
  id: string;
  name: string;
  location: string;
  founder: string;
  industry: string;
  description: string;
  fundingGoal: number;
  image: string;
}
