
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMarketUpdates = async () => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Give me 3 brief, human-like updates about the Indian financial market today. Be concise. No hashtags.",
    });
    return response.text || "Market is stable with slight bullish trends in tech.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Market data currently unavailable. Please check back later.";
  }
};
