
import { Block } from '../types';

class BlockchainService {
  private chain: Block[] = [];
  private difficulty = 3;

  constructor() {
    this.createGenesisBlock();
  }

  private async calculateHash(index: number, timestamp: string, data: string, prevHash: string, nonce: number): Promise<string> {
    const msg = `${index}${timestamp}${data}${prevHash}${nonce}`;
    const msgBuffer = new TextEncoder().encode(msg);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  private async createGenesisBlock() {
    const timestamp = new Date().toISOString();
    const hash = await this.calculateHash(0, timestamp, "Genesis Block", "0", 0);
    this.chain.push({
      index: 0,
      timestamp,
      data: "Genesis Block Initialized",
      prevHash: "0",
      hash,
      nonce: 0,
      status: 'validated'
    });
  }

  public getChain(): Block[] {
    return [...this.chain];
  }

  public setBlockStatus(index: number, status: 'pending' | 'validated') {
    const block = this.chain.find(b => b.index === index);
    if (block) block.status = status;
  }

  public async addBlock(data: string): Promise<Block> {
    const prevBlock = this.chain[this.chain.length - 1];
    const index = prevBlock.index + 1;
    const timestamp = new Date().toISOString();
    const prevHash = prevBlock.hash;
    let nonce = 0;
    let hash = "";

    hash = await this.calculateHash(index, timestamp, data, prevHash, nonce);
    
    const newBlock: Block = {
      index,
      timestamp,
      data,
      prevHash,
      hash,
      nonce,
      status: 'pending'
    };
    
    this.chain.push(newBlock);
    return newBlock;
  }

  public async mineBlock(onProgress: (nonce: number) => void): Promise<Block> {
    const prevBlock = this.chain[this.chain.length - 1];
    const index = prevBlock.index + 1;
    const timestamp = new Date().toISOString();
    const prevHash = prevBlock.hash;
    const data = "Mined Rewards & Validation";
    let nonce = 0;
    let hash = "";

    while (true) {
      hash = await this.calculateHash(index, timestamp, data, prevHash, nonce);
      if (hash.startsWith("0".repeat(this.difficulty))) {
        break;
      }
      nonce++;
      if (nonce % 100 === 0) onProgress(nonce);
      if (nonce % 1000 === 0) await new Promise(r => setTimeout(r, 0));
    }

    const newBlock: Block = {
      index,
      timestamp,
      data,
      prevHash,
      hash,
      nonce,
      status: 'pending'
    };

    this.chain.push(newBlock);
    return newBlock;
  }
}

export const blockchain = new BlockchainService();
